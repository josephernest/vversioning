"""
==CHANGELOG==
* todo: support UTF8
* first vesion
==CHANGELOG==
"""

sqdgfhsqgfksqfkjgsqfkqsgdkfsqkgfqsdf
sqgjdfjsqdhfqgskdgfkqgsdjfsqdfggdsqjf