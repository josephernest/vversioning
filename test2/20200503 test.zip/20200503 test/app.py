"""


==CHANGELOG==
* todo: change name of the project
* first vesion
* support UTF8
* XYZScript support
* refactoring
* new idea implementation
==CHANGELOG==
"""


sqdgfhsqgfksqfkjgsqfkqsgdkfsqkgfqsdf
sqgjdfjsqdhfqgskdgfkqgsdjfsqdfggdsqjf